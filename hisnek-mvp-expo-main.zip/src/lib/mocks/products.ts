export const newsProducts = {
  data: {
    products: [
      {
        id: 1,
        title: 'Smartphone Samsung Galaxy A72',
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.`,
        price: 1999.99,
        image: 'photo-1676121228785-f1dcd462025f',
        quantity: 0,
      },
      {
        id: 2,
        title: 'Smartphone Samsung Galaxy A52',
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.`,
        price: 1499.99,
        image: 'photo-1676121228785-f1dcd462025f',
        quantity: 2,
      },
      {
        id: 3,
        title: 'Smartphone Samsung Galaxy A32',
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.`,
        price: 1299.99,
        image: 'photo-1676121228785-f1dcd462025f',
        quantity: 9,
      },
      {
        id: 4,
        title: 'Smartphone Samsung Galaxy A12',
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.`,
        price: 999.99,
        image: 'photo-1676121228785-f1dcd462025f',
        quantity: 8,
      },
      {
        id: 5,
        title: 'Smartphone Samsung Galaxy A02',
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.`,
        price: 799.99,
        image: 'photo-1676121228785-f1dcd462025f',
        quantity: 7,
      },
    ],
  },
}

export const bestSellersProducts = {
  data: {
    products: [
      {
        id: 6,
        title: 'Smartphone Samsung Galaxy XCover 5',
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.`,
        price: 1999.99,
        image: 'photo-1676121228785-f1dcd462025f',
        quantity: 1,
      },
      {
        id: 7,
        title: 'Smartphone Samsung Galaxy XCover Pro',
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.`,
        price: 1499.99,
        image: 'photo-1676121228785-f1dcd462025f',
        quantity: 10,
      },
      {
        id: 8,
        title: 'Smartphone Samsung Galaxy XCover 4s',
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.`,
        price: 1299.99,
        image: 'photo-1676121228785-f1dcd462025f',
        quantity: 9,
      },
      {
        id: 9,
        title: 'Smartphone Samsung Galaxy XCover Pro 2',
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.`,
        price: 999.99,
        image: 'photo-1676121228785-f1dcd462025f',
        quantity: 8,
      },
      {
        id: 10,
        title: 'Smartphone Samsung Galaxy XCover 3',
        description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vehicula dignissim elit, sit amet tincidunt nisi rhoncus id. Nulla in orci eget magna tincidunt finibus et ac ipsum. Aliquam dolor odio, tincidunt non massa vitae, scelerisque lacinia sem. Pellentesque venenatis cursus neque. Maecenas nec blandit justo. Morbi velit mi, porttitor ut leo at, aliquet euismod metus. Vivamus ac sem vel lacus maximus eleifend. Cras mollis mi neque, a luctus purus tempus in. Aliquam rutrum, leo in cursus finibus, odio nunc porttitor tortor, sit amet cursus nisi ipsum in tortor. Aliquam aliquet felis augue, ut ullamcorper arcu elementum non. Curabitur dapibus nisl justo, et tincidunt orci tempor sed. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.`,
        price: 799.99,
        image: 'photo-1676121228785-f1dcd462025f',
        quantity: 7,
      },
    ],
  },
}

export const allProducts = {
  data: {
    products: [
      ...newsProducts.data.products,
      ...bestSellersProducts.data.products,
    ],
  },
}
