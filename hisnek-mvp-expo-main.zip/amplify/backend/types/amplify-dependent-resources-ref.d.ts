export type AmplifyDependentResourcesAttributes = {
  auth: {
    hisnektestapp8e1ed7a4: {
      AppClientID: 'string'
      AppClientIDWeb: 'string'
      IdentityPoolId: 'string'
      IdentityPoolName: 'string'
      UserPoolArn: 'string'
      UserPoolId: 'string'
      UserPoolName: 'string'
    }
  }
}
