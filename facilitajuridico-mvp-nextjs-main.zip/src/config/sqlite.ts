import sql from 'better-sqlite3'

// eslint-disable-next-line no-console
// export const db = sql('store.db', { verbose: console.log })

export const db = sql('store.db')
