export default function Page() {
  return (
    <div>
      <h1>Dashboard Panel</h1>
    </div>
  )
}
