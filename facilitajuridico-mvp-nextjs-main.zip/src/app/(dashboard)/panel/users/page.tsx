export default function Page() {
  return (
    <div>
      <h1>Users</h1>
    </div>
  )
}
