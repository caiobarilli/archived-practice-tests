import LoadingSlider from '@/components/Slider/loading'

export default function Loading() {
  return <LoadingSlider />
}
