import About from '@/components/About'

export default async function HomeAboutPage() {
  return <About resume />
}
