export default function DefaultPage() {
  return null
}
