import Container from '@/components/Container'

export default async function ShopProductsPage() {
  return (
    <>
      <Container>
        <h2>filter here</h2>
        <h2>products here</h2>
      </Container>
    </>
  )
}
