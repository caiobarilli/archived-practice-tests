import { render } from '@testing-library/react'

import NavSocial from '.'

describe('<NavSocial />', () => {
  it('should render the Component', () => {
    render(<NavSocial />)
  })
})
