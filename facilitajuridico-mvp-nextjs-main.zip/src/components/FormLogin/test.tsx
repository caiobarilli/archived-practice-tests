import { render } from '@testing-library/react'

import FormLogin from '.'

describe('<FormLogin />', () => {
  it('should render the component', () => {
    render(<FormLogin />)
  })
})
