import { render } from '@testing-library/react'

import FormRegister from '.'

describe('<FormRegister />', () => {
  it('should render the component', () => {
    render(<FormRegister />)
  })
})
