export interface ReviewProps {
  id: number
  review: string
}
