<img src="{{ asset('img/Logo.png') }}" alt="Logo">
